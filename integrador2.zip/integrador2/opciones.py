import subprocess
import getpass
import nuevaContraseña
import variables


#Mensaje de bienvenida


print("Hola!! Bienvenido a tu consulta de salario, Dime, ¿Que puesto tienes?")

def seleccion_de_puesto():
    print("1)Gerente\n2)Coordinador\n3)Obrero..... \n(Selecciona tu puesto correspondiente)")
    variables.puesto=input().upper()
    
#CONDICIONAL DE PUESTO SELECCIONADO (LEE Y VALIDA EL PUESTO INGRESADO)
    if variables.puesto != "1" and variables.puesto != "2" and variables.puesto != "3":
        print("\nELIJA UNA OPCION VALIDA POR FAVOR!!!\n")
        seleccion_de_puesto()
        
#MENSAJE DE CONFIRMACION
    else:
        print("\nEscogiste la opcion numero "+variables.puesto+"\nVerifica que sea correcto")
        print("¿Es correcto ese dato?(SI/NO)")
        conf=input().upper()

#CONDICION EN CASO DE HABER CONFIRMADO PUESTO
        if conf == "SI":
            #genera e inicializa los datos del trabajador
            variables.nombre = input("INGRESE SU NOMBRE POR FAVOR: ").upper()
            variables.apellidos = input("INGRESE APELLIDOS POR FAVOR: ").upper()
            variables.correo = str(variables.nombre[0]).lower() + str(variables.apellidos[0:3]).lower() + "@hola.com"
            print("Tu correo es: "+variables.correo)
            print("Tu contraseña es 'ASDFQWER1234'")
            print("Esta es una contraseña generica"+ "\n¡NECESITAS CAMBIARLA PARA CONTINUAR!")
            nuevaContraseña.nueva()
        else:
            print("SELECCIONA TU PUESTO CORRECTAMENTE....")
            seleccion_de_puesto()
seleccion_de_puesto()