global Contra
global correo
global puesto
global nombre
global apellidos

bkup= open('backup.txt','a')
