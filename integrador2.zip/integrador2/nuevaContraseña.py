import getpass
import ingresar
import variables

def nueva():
    print("Ingresa tu contraseña generica: ")
    cambio=getpass.getpass()
    if cambio =="ASDFQWER1234":
        print("Ingresa tu nueva contraseña: ")
        nuevaCont=getpass.getpass()
        if len(nuevaCont) < 8 :
            print("ingresa una contraseña con mas de 8 caracteres")
            nueva()
        else:
            print("Confirma Contraseña nueva: ")
            verconnu = getpass.getpass()
            if verconnu != nuevaCont:
                    print("Los datos no coinciden, verifique nuevamente")
                    nueva()  
            else:
                print("Has cambiado tu contraseña con exito")
                variables.Contra = verconnu
                print(variables.Contra[-3:-1]+variables.Contra[-1]) 
                print("\nPara obtener su estado de cuenta, por favor, ingrese su correo y contraseña\n")
                ingresar.login()
    else:
        print("Contraseña Inválida")
        nueva()

    
