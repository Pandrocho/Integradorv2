import getpass
import variables
import ejecucion

def login():
    corr = input("Correo: \n")
    print("Contraseña: ")
    
    con = getpass.getpass()
    if corr != variables.correo or con != variables.Contra:
        print("Datos invalidos, favor de verificar")
        login()
    else:
        print("Usted ha ingresado exitosamente")
        ejecucion.ejec()
