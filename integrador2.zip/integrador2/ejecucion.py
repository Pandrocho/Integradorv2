import variables
def ejec():
    if variables.puesto == "1":
        
                    salario_inicial = 24000
                    SegSoc= salario_inicial * 0.062
                    IVA=salario_inicial * 0.16
                    ifv = input("¿Cuenta con infonavit? (SI/NO) ").upper()
                    
                    if ifv == "SI":
                        #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI CUENTA CON INFONAVIT
                        Infonavit= salario_inicial * 0.05
                        salario_final = salario_inicial -SegSoc - Infonavit- IVA 
                        
                        print("\n\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                        print("Puesto: GERENTE")
                        print("Tu correo es: "+variables.correo)
                        print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                        print("Tu descuento de vivienda : "+"$"+str(Infonavit))
                        print("IVA: "+str(IVA))
                        print ("Tu nuevo salario neto mensual es de: "+ "$"+str(salario_final))
                        variables.bkup.write(
                        "----------------------------------------------------------------------------"
                        "\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                        +print("Puesto: GERENTE")
                        +"\nTu correo es: "+variables.correo+
                        "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                        "\nTu descuento de vivienda : "+"$"+str(Infonavit)+
                        "\nIVA: "+str(IVA)+
                        "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                        +"\n---------------------------------------------------------------------------\n"
                        )
                    else:
                        #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI NO CUENTA CON INFONAVIT
                        salario_final = salario_inicial -SegSoc -  IVA 
                        correo = str(variables.nombre[0]).lower() + str(variables.apellidos[0:3]).lower() + "@hola.com"
                        print("\n\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                        print("Puesto: GERENTE")
                        print("Tu correo es: "+variables.correo)
                        print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                        print("IVA: "+str(IVA))
                        print ("Tu nuevo salario neto mensual es de: "+"$"+ str(salario_final))
                        variables.bkup.write(
                        "----------------------------------------------------------------------------"
                        "\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                        +"\nPuesto: GERENTE"
                        +"\nTu correo es: "+variables.correo+
                        "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                        "\nIVA: "+str(IVA)+
                        "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                        +"\n---------------------------------------------------------------------------\n"
                        )
                        
                #INGRESA DATOS DE EMPLEADO
    elif variables.puesto == "2":
                    salario_inicial = 15000
                    SegSoc= salario_inicial * 0.062
                    IVA=salario_inicial * 0.16
                    ifv = input("¿Cuenta con infonavit? (SI/NO) ").upper()
                    
                    if ifv == "SI":
                    
                        
                        #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI CUENTA CON INFONAVIT
                        Infonavit= salario_inicial * 0.05
                        salario_final = salario_inicial -SegSoc - Infonavit- IVA 
                        correo = str(variables.nombre[0]).lower() + str(variables.apellidos[0:3]).lower() + "@hola.com"

                        print("\n\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                        print("Puesto: COORDINADOR")
                        print("Tu correo es: "+variables.correo)
                        print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                        print("Tu descuento de vivienda : "+"$"+str(Infonavit))
                        print("IVA: "+str(IVA))
                        print ("Tu nuevo salario neto mensual es de: "+"$"+ str(salario_final))
                        variables.bkup.write(
                        "----------------------------------------------------------------------------"
                        "\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                        +"\nPuesto: COORDINADOR"
                        +"\nTu correo es: "+variables.correo+
                        "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                        "\nTu descuento de vivienda : "+"$"+str(Infonavit)+
                        "\nIVA: "+str(IVA)+
                        "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                        +"\n---------------------------------------------------------------------------\n"
                        )
                    else:
                      
                        #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI NO CUENTA CON INFONAVIT
                        salario_final = salario_inicial -SegSoc -  IVA 
                        correo = str(variables.nombre[0]).lower() + str(variables.apellidos[0:3]).lower() + "@hola.com"
                        print("\n\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                        print("Puesto: COORDINADOR")
                        print("Tu correo es: "+variables.correo)
                        print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                        print("IVA: "+str(IVA))
                        print ("Tu nuevo salario neto mensual es de: "+"$"+ str(salario_final))
                        variables.bkup.write(
                        "----------------------------------------------------------------------------"
                        "\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                        +"\nPuesto: COORDINADOR"
                        +"\nTu correo es: "+variables.correo+
                        "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                        "\nIVA: "+str(IVA)+
                        "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                        +"\n---------------------------------------------------------------------------\n"
                        )
                        
                #INGRESA DATOS DE EMPLEADO
    elif variables.puesto == "3":
                    
                    salario_inicial = 6000
                    SegSoc= salario_inicial * 0.062
                    IVA=salario_inicial * 0.16
                    ifv = input("¿Cuenta con infonavit? (SI/NO) ").upper()
                    if ifv == "SI":
                        
                        #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI CUENTA CON INFONAVIT
                        Infonavit= salario_inicial * 0.05
                        salario_final = salario_inicial -SegSoc - Infonavit- IVA 
                        correo = str(variables.nombre[0]).lower() + str(variables.apellidos[0:3]).lower() + "@hola.com"

                        print("\n\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                        print("Puesto: OBRERO")
                        print("Tu correo es: "+variables.correo)
                        print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                        print("Tu descuento de vivienda : "+"$"+str(Infonavit))
                        print("IVA: "+str(IVA))
                        print ("Tu nuevo salario neto mensual es de: "+ "$"+str(salario_final))
                        variables.bkup.write(
                        "----------------------------------------------------------------------------"
                        "\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                        +"\nPuesto: OBRERO"
                        +"\nTu correo es: "+variables.correo+
                        "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                        "\nTu descuento de vivienda : "+"$"+str(Infonavit)+
                        "\nIVA: "+str(IVA)+
                        "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                        +"\n---------------------------------------------------------------------------\n"
                        )
                    else:
                        
                        #DESGLOSE DE SALARIO, IMPUESTOS Y OTRAS PRESTACIONES SI NO CUENTA CON INFONAVIT
                        salario_final = salario_inicial -SegSoc -  IVA 
                        correo = str(variables.nombre[0]).lower() + str(variables.apellidos[0:3]).lower() + "@hola.com"

                        print("\n\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial))
                        print("Puesto: OBRERO")
                        print("Tu correo es: "+variables.correo)
                        print("Tu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc))
                        print("IVA: "+str(IVA))
                        print ("Tu nuevo salario neto mensual es de: "+"$"+ str(salario_final))
                        variables.bkup.write(
                        "----------------------------------------------------------------------------"
                        "\nTus datos son :\nNombre: "+variables.nombre+"\nApellidos: "+variables.apellidos+"\nSalario mensual (sin impuestos): "+"$"+str(salario_inicial)
                        +"\nPuesto: OBRERO"
                        +"\nTu correo es: "+variables.correo+
                        "\nTu Descuento de Seguro Social equivale a: "+"$"+str(SegSoc)+
                        "\nIVA: "+str(IVA)+
                        "\nTu nuevo salario neto mensual es de: "+"$"+ str(salario_final)
                        +"\n---------------------------------------------------------------------------\n"
                        )
                
                #SI NO SE CUMPLE NINGUNA DE LAS CONDICIONES DE PUESTO
  
                    
            


